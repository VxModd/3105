# Paquetes `.3105` con variantes

La versión 1.2.0 añade soporte para que un único paquete `.3105` contenga dos o más proyectos independientes llamados **variantes**. Cada variante conserva su propio UUID de proyecto, workspace, conjunto de reglas y transacción de recuperación.

## Modelo de datos

Los paquetes v1 y v2 siguen usando un payload con un único `project`. Los paquetes v3 usan `variants: [PatchProject]` y un mapa `replacementDigests` que cubre todas las reglas de todas las variantes. El envelope mantiene el mismo prefijo `3105PATCH`, la clave de contenido de 32 bytes, la huella SHA-256 y el cifrado autenticado AES-GCM. El `packageID` identifica el contenedor del paquete; los UUID de las variantes son independientes.

La validación exige al menos dos variantes, UUIDs de variante únicos, reglas sin destinos duplicados dentro de cada variante y UUIDs de regla únicos en todo el paquete. Los hashes de reemplazo se verifican antes de exponer el contenido a la interfaz.

## Flujo de usuario

Desde **Patch → Add → New Variant Package**, el usuario crea al menos dos proyectos. Cada proyecto se configura con el editor existente, incluyendo nombre, bundle ID, rutas y archivos de reemplazo. Al abrir el paquete, la pantalla de detalle muestra un `Picker` de variantes. **Apply Patch** sincroniza el workspace de la variante seleccionada y pasa solamente ese `PatchProject` a `DevicePatchService`.

La transacción usa el UUID de la variante seleccionada. Por ello, **Restore Originals** solo restaura la variante aplicada, sin tocar otras variantes del mismo paquete. **Export** sincroniza todos los workspaces antes de compartir el paquete para no perder cambios hechos en una variante no seleccionada.

## Compilación sin firma

La máquina de desarrollo debe ser macOS con Xcode y un SDK de iOS compatible con el deployment target 16.0. Desde Terminal, sitúate en la raíz del proyecto y ejecuta:

```sh
chmod +x build_unsigned_ipa.sh
./build_unsigned_ipa.sh
```

El script ejecuta `xcodebuild` en Release con `CODE_SIGNING_ALLOWED=NO`, `CODE_SIGNING_REQUIRED=NO`, identidad vacía y sin equipo de desarrollo. Después copia el `.app` a `Payload/` y lo comprime como `dist/3105-variants-unsigned.ipa`.

Una IPA sin firma no es instalable por sí sola en un dispositivo. Debe firmarse posteriormente con el método y los entitlements que el usuario tenga autorizados. El proyecto conserva el bundle ID `com.apple.mobile.MobileHouseArrest`, porque el flujo MHA-C2 de la app depende de esa identidad.

## Limitación de verificación

El proyecto fue revisado y validado estáticamente en Linux. El entorno de trabajo no incluye `xcodebuild`, `xcode-select`, `swiftc` ni el SDK de iOS, por lo que aquí no es posible producir o probar una IPA real. El script de compilación queda incluido para ejecutarse en macOS. La aplicación real debe probarse primero en un dispositivo de pruebas y con una copia de seguridad de los datos.
