# Verificación de 3105 v1.2.0 con variantes

## Cambios implementados

La versión modificada incrementa la aplicación a marketing version `1.2.0` y build `8`. El codec admite los paquetes históricos v1/v2 y añade el esquema v3 para un único `.3105` con dos o más `PatchProject` independientes. Se añadió un compositor en la pestaña Patch, un selector de variante en el detalle, sincronización selectiva al aplicar y journaling/restauración por UUID de variante.

## Pruebas realizadas

| Prueba | Resultado |
|---|---|
| Balance de delimitadores en los cinco archivos Swift modificados | Superada |
| Duplicados en las tres localizaciones `.strings` | Superada |
| Parseo del `Info.plist` | Superada |
| Generación y lectura de payload v3 con dos variantes | Superada |
| Autenticación AES-GCM y verificación de hashes del fixture v3 | Superada |
| Presencia de claves de localización de variantes en inglés, vietnamita y chino | Superada |
| Compilación local con `xcodebuild` | No disponible |

## Limitación de compilación

La máquina actual ejecuta Linux y no contiene `xcodebuild`, `xcode-select`, `swiftc` ni un SDK de iOS. Al intentar ejecutar `build_unsigned_ipa.sh`, el sistema devolvió `xcodebuild: not found`. En consecuencia, no es técnicamente posible producir aquí una IPA iOS sin firma ni afirmar que el código compile hasta probarlo en macOS con Xcode.

El proyecto incluye `build_unsigned_ipa.sh`, que en macOS ejecuta una compilación Release con `CODE_SIGNING_ALLOWED=NO`, `CODE_SIGNING_REQUIRED=NO`, identidad vacía y sin equipo de desarrollo; después empaqueta `Payload/3105.app` como una IPA sin firma.
