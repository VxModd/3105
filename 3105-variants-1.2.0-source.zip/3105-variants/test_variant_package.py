#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import plistlib
import secrets
import sys
import uuid
from datetime import datetime
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAGIC = b"3105PATCH\x00"
VERSION = 3
BUNDLE = "com.dts.freefireth"
PATH = "Documents/contentcache/Compulsory/ios/gameassetbundles/cache_res.CfnFf59sr1SbsqQ6JqTKsEusjKs~3D"
FILENAME = "cache_res.CfnFf59sr1SbsqQ6JqTKsEusjKs~3D"


def uuid_string() -> str:
    return str(uuid.uuid4()).upper()


def project(name: str, data: bytes) -> tuple[dict, str]:
    project_id = uuid_string()
    rule_id = uuid_string()
    now = datetime.utcnow().replace(microsecond=0)
    rule = {
        "id": rule_id,
        "bundleID": BUNDLE,
        "relativePath": PATH,
        "replacementFilename": FILENAME,
        "replacementData": data,
    }
    return ({
        "id": project_id,
        "name": name,
        "createdAt": now,
        "updatedAt": now,
        "bundleIdentifiers": [BUNDLE],
        "directories": [],
        "rules": [rule],
    }, rule_id)


def seal(data: bytes, key: bytes, aad: bytes) -> bytes:
    nonce = secrets.token_bytes(12)
    return nonce + AESGCM(key).encrypt(nonce, data, aad)


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit(f"usage: {sys.argv[0]} OUTPUT")
    source = Path("/home/ubuntu/upload/cache_res.CfnFf59sr1SbsqQ6JqTKsEusjKs~3D").read_bytes()
    alternative = source[:-1] + bytes([source[-1] ^ 0x01])
    first, first_rule = project("Asset original", source)
    second, second_rule = project("Asset alternative", alternative)
    package_id = uuid_string()
    key = secrets.token_bytes(32)
    payload = {
        "variants": [first, second],
        "replacementDigests": {
            first_rule: hashlib.sha256(source).digest(),
            second_rule: hashlib.sha256(alternative).digest(),
        },
    }
    payload_data = plistlib.dumps(payload, fmt=plistlib.FMT_BINARY, sort_keys=False)
    aad = f"3105PATCH/v{VERSION}/payload/{package_id}".encode()
    envelope = {
        "schemaVersion": VERSION,
        "packageID": package_id,
        "isPasswordProtected": False,
        "publicContentKey": key,
        "keyFingerprint": hashlib.sha256(key).digest(),
        "encryptedPayload": seal(payload_data, key, aad),
    }
    output = Path(sys.argv[1])
    output.write_bytes(MAGIC + plistlib.dumps(envelope, fmt=plistlib.FMT_BINARY, sort_keys=False))

    stored = plistlib.loads(output.read_bytes()[len(MAGIC):])
    encrypted = stored["encryptedPayload"]
    decoded = plistlib.loads(AESGCM(stored["publicContentKey"]).decrypt(
        encrypted[:12], encrypted[12:], aad
    ))
    variants = decoded["variants"]
    assert len(variants) == 2
    assert {variant["name"] for variant in variants} == {"Asset original", "Asset alternative"}
    assert all(variant["bundleIdentifiers"] == [BUNDLE] for variant in variants)
    assert all(variant["rules"][0]["relativePath"] == PATH for variant in variants)
    assert hashlib.sha256(variants[0]["rules"][0]["replacementData"]).digest() == decoded["replacementDigests"][first_rule]
    assert hashlib.sha256(variants[1]["rules"][0]["replacementData"]).digest() == decoded["replacementDigests"][second_rule]
    print(f"PASS: schema={stored['schemaVersion']}")
    print(f"PASS: variants={len(variants)}")
    print(f"PASS: selected_variant_example={variants[1]['name']}")
    print(f"PASS: package_sha256={hashlib.sha256(output.read_bytes()).hexdigest()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
